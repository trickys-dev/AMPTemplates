const pm2 = require('pm2')

pm2.connect(err => {
    if (err) {
        console.error(err)
        process.exit(2)
    }

    pm2.start({
        script: '../start.bat',
        cwd: '../',
        name: 'motortown',
        interpreter: 'none'
    }, (err, apps) => {
        console.log(apps);
        pm2.disconnect()
        if (err) throw err
    })
})

process.stdin.on('data', data => { 
    if (data.toString().trim() === 'stop') {
        pm2.connect(err => {
            if (err) {
                console.error(err)
            }
            pm2.delete('motortown', (err, apps) => {
                console.log("stopped");
                pm2.disconnect()
                process.exit(0);
                if (err) throw err
            })
        })
    }
});